# python_solvers.py, contains the definitions for the BaseSolver class and the SOO solver classes

from typing import Callable, Sequence, Tuple, Dict
import numpy as np

# pip install scipy
from scipy.optimize import differential_evolution
from scipy.optimize import dual_annealing
from scipy.optimize import direct

# pip install nevergrad
import nevergrad as ng

# pip install pymoo
from pymoo.algorithms.soo.nonconvex.ga import GA
from pymoo.core.problem import Problem as PymooProblem
from pymoo.optimize import minimize

# # pip install smt
# from smt.applications.ego import EGO
# from smt.sampling_methods import LHS
# from smt.surrogate_models import KRG
# from smt.design_space import DesignSpace

# pip install torch botorch ax-platform
# from ax.service.managed_loop import optimize

# pip install OMADS
from OMADS import MADS  # MADS is the module


# === Robust squashing wrapper (shared by SciPy/NG/OMADS/pymoo) ===
def _build_squashed_objective(prob, bounds, n_probes=24, clip=1e300, rng=None):
    """
    Return safe_obj(x) which evaluates prob.objective(x) in RAW space,
    then returns a sign-preserving squashed value arcsinh(y/scale).
    The scale is estimated via quick random probes in the box `bounds`.
    """
    rng = np.random.default_rng(None if rng is None else rng)
    lb = np.array([b[0] for b in bounds], dtype=float)
    ub = np.array([b[1] for b in bounds], dtype=float)
    dim = lb.size

    samples = []
    for _ in range(int(max(1, n_probes))):
        u = rng.random(dim)
        x = lb + u * (ub - lb)
        y = prob.objective(x)
        if np.isfinite(y):
            samples.append(abs(y))

    if samples:
        scale = float(np.median(samples))
        if not np.isfinite(scale) or scale <= 0:
            pos = [s for s in samples if s > 0]
            scale = float(np.mean(pos)) if pos else 1.0
    else:
        scale = 1.0

    scale = max(scale, 1e-12)

    def _squash(y: float) -> float:
        if not np.isfinite(y):
            y = np.sign(y) * clip
        else:
            y = float(np.clip(y, -clip, clip))
        return float(np.arcsinh(y / scale))

    def safe_obj(x):
        y = prob.objective(np.asarray(x, dtype=float))
        return _squash(y)

    return safe_obj

# ===================================
# 1) PROBLEM
# ===================================
# each time solver creates a new instance of the Problem class, which stores the history, running minima, and instance
class Problem:
    def __init__(self, dim: int, instance: int, bounds: Sequence[Tuple[float, float]], objective: Callable[[np.ndarray], float]):
        self.dim = dim
        self.instance = instance
        self.bounds = bounds
        self.history = []
        self.best_so_far = []

        # Wrap the objective to log evaluations
        orig_obj = objective

        def wrapped(x):
            x = np.asarray(x).flatten()
            val = orig_obj(x)
            
            #if not np.isfinite(val):
                #print(f"[WARN] Received non-finite objective: x={x}, val={val}")
            #else:
                #print(f"[OK] method called objective: x={x}, val={val}")
            self.history.append(val)
            if not self.best_so_far:
                self.best_so_far.append(val)
            else:
                self.best_so_far.append(min(self.best_so_far[-1], val))
            return val

        self.objective = wrapped

# ===================================
# 2) BASE SOLVER
# ===================================
class BaseSolver:
    name: str = "Base"
    # instantiates the budget to 1000
    def __init__(self, budget: int = 1000):
        self.budget = budget
    def solve(self, prob: Problem) -> Dict:
        raise NotImplementedError

# ===================================
# 3) SOLVER WRAPPERS 
# ===================================

# SciPy Differential Evolution
class SciPyDE(BaseSolver):
    name = "SciPy-DE"
    def solve(self, prob: Problem) -> Dict:

        popsize = 50 
        n_evals_per_iter = popsize * prob.dim
        maxiter = int((self.budget - n_evals_per_iter) / n_evals_per_iter)
        safe_obj = _build_squashed_objective(prob, prob.bounds)
        res = differential_evolution(safe_obj, prob.bounds, maxiter=maxiter, popsize=popsize, disp=False, polish=False, seed=prob.instance)
        return dict(x=res.x, f=res.fun, n_eval=res.nfev, history=prob.history.copy(), best=prob.best_so_far.copy())

# SciPy Dual Annealing
class SciPyDA(BaseSolver):
    name = "SciPy-DA"
    def solve(self, prob: Problem) -> Dict:
            safe_obj = _build_squashed_objective(prob, prob.bounds)
            res = dual_annealing(safe_obj, bounds=prob.bounds, maxfun=self.budget, no_local_search=True, seed=prob.instance)
            return dict(x=res.x, f=res.fun, n_eval=res.nfev, history=prob.history.copy(), best=prob.best_so_far.copy())

# SciPy DIRECT
class SciPyDIRECT(BaseSolver):
    name = "SciPy-DIRECT"
    def solve(self, prob: Problem) -> Dict:
        safe_obj = _build_squashed_objective(prob, prob.bounds)
        res = direct(safe_obj, prob.bounds, maxfun=self.budget) # no seed as it is a deterministic approach
        return dict(x=res.x, f=res.fun, n_eval=res.nfev, history=prob.history.copy(), best=prob.best_so_far.copy())

# Nevergrad NgIohTuned
class NGIoh(BaseSolver):
    name = "Nevergrad"

    def solve(self, prob: Problem) -> Dict:
        np.random.seed(prob.instance)
        instr = ng.p.Array(shape=(prob.dim,)).set_bounds(*zip(*prob.bounds))
        safe_obj = _build_squashed_objective(prob, prob.bounds)

        opt = ng.optimizers.NgIohTuned(parametrization=instr, budget=self.budget)
        rec = opt.minimize(safe_obj)

        # Return metrics in the original scale to keep your benchmarks comparable
        x_star = np.asarray(rec.value)
        f_raw = float(prob.objective(x_star))

        return dict(
            x=x_star,
            f=f_raw,
            n_eval=opt.num_ask,
            history=prob.history.copy(),
            best=prob.best_so_far.copy(),
        )

# pymoo GA 
class PymooGA(BaseSolver):
    name = "pymoo-GA"
    def solve(self, prob: Problem) -> Dict:
        xl = np.array([b[0] for b in prob.bounds])
        xu = np.array([b[1] for b in prob.bounds])
        safe_obj = _build_squashed_objective(prob, prob.bounds)

        class _MyProb(PymooProblem):
            def __init__(self):
                super().__init__(n_var=prob.dim, n_obj=1, n_constr=0, xl=xl, xu=xu, elementwise=True)
            def _evaluate(self, x, out):
                out["F"] = safe_obj(x)
        alg = GA(pop_size=100, eliminate_duplicates=True)
        res = minimize(_MyProb(), alg, termination=("n_gen", self.budget // (50 * 2)), verbose=False, seed=prob.instance)
        
        if res.F is None or res.X is None:
            return dict(error="No feasible solution found", f=float("inf"), n_eval=0, history=[], best=[])

        return dict(x=res.X, f=res.F[0], n_eval=res.algorithm.evaluator.n_eval, history=prob.history.copy(), best=prob.best_so_far.copy())

# SMT EGO (not used)
# class SMTEGO(BaseSolver):
#     name = "SMT-EGO"

#     def solve(self, prob: Problem) -> Dict:
#         # Setup
#         xlimits = np.array(prob.bounds)
#         design_space = DesignSpace(xlimits)
#         init_points = 150 # what dakota's ego defaults to 
#         n_parallel = 1
#         n_iter = 50 # 1000 would be way too many

#         # Sample initial DoE
#         sampling = LHS(xlimits=xlimits, criterion="ese", random_state=prob.instance)
#         x_doe = sampling(init_points)
#         y_doe = np.array([prob.objective(xi) for xi in x_doe]).reshape(-1, 1)

#         # Surrogate model
#         surrogate = KRG(design_space=design_space)

#         # Build EGO model
#         ego = EGO(
#             n_iter=n_iter,
#             xdoe=x_doe,
#             ydoe=y_doe,
#             surrogate=surrogate,
#             criterion="EI",
#             n_parallel=n_parallel,
#             random_state=prob.instance,
#         )

#         x_opt, y_opt, _, x_data, y_data = ego.optimize(fun=prob.objective)

#         return dict(
#             x=x_opt,
#             f=y_opt.item(),
#             n_eval=len(x_data),
#             history=prob.history.copy(),
#             best=prob.best_so_far.copy(),
#         )

# Ax / BoTorch BO
class AxBO(BaseSolver):
    name = "Ax-BO"
    def solve(self, prob: Problem) -> Dict:            
        parameters = [{"name": f"x{i}", "type": "range", "bounds": list(prob.bounds[i])} for i in range(prob.dim)]

        def _eval(params):
            x = np.array([params[f"x{i}"] for i in range(prob.dim)], dtype=float)
            result = {"obj": prob.objective(x)}
            return result

        kwargs = {
            "parameters": parameters,
            "evaluation_function": _eval,
            "minimize": True,
            "objective_name": "obj",
            "total_trials": 150,
            "random_seed": prob.instance
        }

        try:
            bp, bv, exp, _ = optimize(**kwargs) 
            return dict(
                x=np.array([bp[f"x{i}"] for i in range(prob.dim)]),
                f=bv[0]["obj"],
                n_eval=len(exp.trials),
                history=prob.history.copy(),
                best=prob.best_so_far.copy())
        
        # gracefully handling errors
        except Exception as e:
            if 'exp' in locals():  # Check if experiment exists
                try:
                    # Get all evaluated points
                    df = exp.fetch_data().df
                    
                    # Find points that violate the fewest violations
                    best_infeasible_idx = df['obj'].idxmin()
                    
                    return dict(
                        x=np.array([df.loc[best_infeasible_idx][f"x{i}"] for i in range(prob.dim)]),
                        f=float(df.loc[best_infeasible_idx]['obj']),
                        n_eval=len(exp.trials),
                        history=prob.history.copy(),
                        best=prob.best_so_far.copy(),
                        warning="Using best infeasible solution"
                    )
                except:
                    pass
                    
            # Ultimate fallback if everything fails
            return dict(
                error=f"Optimization failed: {str(e)}",
                f=float('inf'),
                n_eval=0,
                history=[],
                best=[]
            )
# OMADS
class OMADSSolver(BaseSolver):
    name = "OMADS"

    def solve(self, prob: Problem) -> Dict:
        lb = np.array([b[0] for b in prob.bounds], dtype=float)
        ub = np.array([b[1] for b in prob.bounds], dtype=float)
        span = ub - lb
        safe_obj = _build_squashed_objective(prob, prob.bounds)

        def to_x(z):
            z = np.asarray(z, float).flatten()
            return lb + z * span

        def omads_obj(z):
            return safe_obj(to_x(z))

        # jittered baseline so instances differ
        rng = np.random.default_rng(prob.instance)
        z0 = np.clip(0.5 + 0.05 * rng.standard_normal(prob.dim), 0.0, 1.0)

        data = {
            "evaluator": {"blackbox": omads_obj},
            "param": {
                "baseline": z0.tolist(),
                "lb": [0.0] * prob.dim,
                "ub": [1.0] * prob.dim,
                "var_names": [f"x{i+1}" for i in range(prob.dim)],
                "post_dir": "./omads_post",
                "Failure_stop": False,   # keep going on bad evals
            },
            "options": {
                "seed": prob.instance,
                "budget": self.budget,
                "tol": 1e-6,             # allow early stop
                "display": False,
                "check_cache": True,
                "store_cache": True,
                "rich_direction": True,
                "opportunistic": True,   # faster & more stochastic
                "save_results": False,
                "isVerbose": False,
                "psize_init": 0.20,      # fraction of [0,1] box
                "precision": "low",      # less brittle comparisons
            },
            "sampling": {
                # if OMADS supports 'LHS', use it; else keep ORTHO but add jittered baseline above
                "method": "LHS",
                "ns": min(2 * prob.dim + 2, 40),
            },
            "search": {
                "type": "QUAD",
                "ns": min(prob.dim + 1, 20),
            },
        }

        output, _ = MADS.main(data)

        # map back & report RAW f
        z_star = np.array(output["xmin"], float).reshape(-1)
        x_star = to_x(z_star)
        f_raw = float(prob.objective(x_star))

        return dict(
            x=x_star,
            f=f_raw,
            n_eval=output.get("nbb_evals", None),
            history=prob.history.copy(),
            best=prob.best_so_far.copy(),
        )
